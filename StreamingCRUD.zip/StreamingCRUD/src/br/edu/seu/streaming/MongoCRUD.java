package br.edu.seu.streaming;

import com.mongodb.client.*;
import org.bson.Document;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;

public class MongoCRUD {

    public static void main(String[] args) {
    	String uri = "mongodb+srv://fraziunnn:frazao999@fraziunnn.r2xrmus.mongodb.net/?appName=Fraziunnn";
        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase db = mongoClient.getDatabase("streaming");
            MongoCollection<Document> usuarios = db.getCollection("usuarios");

            // Inserir
            Document usuario = new Document("nome", "Carlos")
                    .append("idade", 28)
                    .append("assinatura", "Premium")
                    .append("generoPreferido", "Ação");
            usuarios.insertOne(usuario);
            System.out.println("Inserido: " + usuario.toJson());

            // Listar
            for (Document doc : usuarios.find()) {
                System.out.println(doc.toJson());
            }

            // Buscar
            Document encontrado = usuarios.find(eq("nome", "Carlos")).first();
            System.out.println("Encontrado: " + (encontrado != null ? encontrado.toJson() : "null"));

            // Atualizar
            usuarios.updateOne(eq("nome", "Carlos"), set("assinatura", "Gold"));
            Document atualizado = usuarios.find(eq("nome", "Carlos")).first();
            System.out.println("Atualizado: " + (atualizado != null ? atualizado.toJson() : "null"));

            // Deletar
            usuarios.deleteOne(eq("nome", "Carlos"));
            Document deletado = usuarios.find(eq("nome", "Carlos")).first();
            System.out.println("Deletado. Agora buscar retorna: " + (deletado != null ? deletado.toJson() : "null"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
