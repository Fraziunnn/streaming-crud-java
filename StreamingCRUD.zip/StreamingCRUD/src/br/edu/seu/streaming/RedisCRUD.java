package br.edu.seu.streaming;

import redis.clients.jedis.Jedis;

public class RedisCRUD {

    public static void main(String[] args) {
        // Conectar ao Redis local
        try (Jedis jedis = new Jedis("localhost", 6379)) {

            // Inserir
            jedis.hset("usuario:Carlos", "nome", "Carlos");
            jedis.hset("usuario:Carlos", "idade", "28");
            jedis.hset("usuario:Carlos", "assinatura", "Premium");
            jedis.hset("usuario:Carlos", "generoPreferido", "Ação");
            System.out.println("Inserido: " + jedis.hgetAll("usuario:Carlos"));

            // Buscar
            System.out.println("Buscar: " + jedis.hgetAll("usuario:Carlos"));

            // Atualizar
            jedis.hset("usuario:Carlos", "assinatura", "Gold");
            System.out.println("Atualizado: " + jedis.hgetAll("usuario:Carlos"));

            // Deletar
            jedis.del("usuario:Carlos");
            System.out.println("Deletado. Existe? " + jedis.exists("usuario:Carlos"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
